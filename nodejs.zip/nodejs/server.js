//1.引入express
const express = require("express");
//2.创建应用对象
const app = express();

//设置跨域访问
app.all('*', function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
    res.header('Access-Control-Allow-Headers', 'Content-Type, Content-Length, Authorization, Accept, X-Requested-With , yourHeaderFeild');
    res.header("X-Powered-By", ' 3.2.1')
    res.header("Content-Type", "application/json;charset=utf-8");
    next();
});
//五星人物
const star5_character1 = {
    src_p: "../img/5star/character/莫娜.jpg",
    name: "莫娜"
};
const star5_character2 = {
    src_p: "../img/5star/character/七七.jpg",
    name: "七七"
};
const star5_character3 = {
    src_p: "../img/5star/character/琴.jpg",
    name: "琴"
};
const star5_character4 = {
    src_p: "../img/5star/character/温迪.jpg",
    name: "温迪"
};
const star5_character5 = {
    src_p: "../img/5star/character/魈.jpg",
    name: "魈"
};
const star5_character6 = {
    src_p: "../img/5star/character/胡桃.jpg",
    name: "胡桃"
};
const star5_character7 = {
    src_p: "../img/5star/character/可莉.jpg",
    name: "可莉"
};
const star5_character8 = {
    src_p: "../img/5star/character/优菈.jpg",
    name: "优菈"
};
const star5_character9 = {
    src_p: "../img/5star/character/钟离.jpg",
    name: "钟离"
};
const star5_character10 = {
    src_p: "../img/5star/character/阿贝多.jpg",
    name: "阿贝多"
};
const star5_character11 = {
    src_p: "../img/5star/character/迪卢克.jpg",
    name: "迪卢克"
};
const star5_character12 = {
    src_p: "../img/5star/character/甘雨.jpg",
    name: "甘雨"
};

//五星武器
const star5_arms1 = {
    src_p: "../img/5star/arms/阿莫斯之弓.jpg",
    name: "阿莫斯之弓"
};
const star5_arms2 = {
    src_p: "../img/5star/arms/尘世之锁.jpg",
    name: "尘世之锁"
};
const star5_arms3 = {
    src_p: "../img/5star/arms/风鹰剑.jpg",
    name: "风鹰剑"
};
const star5_arms4 = {
    src_p: "../img/5star/arms/贯虹之槊.jpg",
    name: "贯虹之槊"
};
const star5_arms5 = {
    src_p: "../img/5star/arms/和璞鸢.jpg",
    name: "和璞鸢"
};
const star5_arms6 = {
    src_p: "../img/5star/arms/护摩之杖.jpg",
    name: "护摩之杖"
};
const star5_arms7 = {
    src_p: "../img/5star/arms/狼的末路.jpg",
    name: "狼的末路"
};
const star5_arms8 = {
    src_p: "../img/5star/arms/磐岩结绿.jpg",
    name: "磐岩结绿"
};
const star5_arms9 = {
    src_p: "../img/5star/arms/四风原典.jpg",
    name: "四风原典"
};
const star5_arms10 = {
    src_p: "../img/5star/arms/松籁响起之时.jpg",
    name: "松籁响起之时"
};

const star5_arms11 = {
    src_p: "../img/5star/arms/天空之傲.jpg",
    name: "天空之傲"
};
const star5_arms12 = {
    src_p: "../img/5star/arms/天空之脊.jpg",
    name: "天空之脊"
};
const star5_arms13 = {
    src_p: "../img/5star/arms/天空之卷.jpg",
    name: "天空之卷"
};
const star5_arms14 = {
    src_p: "../img/5star/arms/天空之刃.jpg",
    name: "天空之刃"
};
const star5_arms15 = {
    src_p: "../img/5star/arms/天空之翼.jpg",
    name: "天空之翼"
};
const star5_arms16 = {
    src_p: "../img/5star/arms/无工之剑.jpg",
    name: "无工之剑"
};
const star5_arms17 = {
    src_p: "../img/5star/arms/终末嗟叹之诗.jpg",
    name: "终末嗟叹之诗"
};
const star5_arms18 = {
    src_p: "../img/5star/arms/斫峰之刃.jpg",
    name: "斫峰之刃"
};
//四星
const star4_1 = {
    src_p: "../img/4star/芭芭拉.jpg",
    name: "芭芭拉"
};
const star4_2 = {
    src_p: "../img/4star/班尼特.jpg",
    name: "班尼特"
};
const star4_3 = {
    src_p: "../img/4star/北斗.jpg",
    name: "北斗"
};
const star4_4 = {
    src_p: "../img/4star/芭芭拉.jpg",
    name: "芭芭拉"
};
const star4_5 = {
    src_p: "../img/4star/迪奥娜.jpg",
    name: "迪奥娜"
};

const star4_6 = {
    src_p: "../img/4star/笛剑.jpg",
    name: "笛剑"
};
const star4_7 = {
    src_p: "../img/4star/菲谢尔.jpg",
    name: "菲谢尔"
};
const star4_8 = {
    src_p: "../img/4star/弓藏.jpg",
    name: "弓藏"
};
const star4_9 = {
    src_p: "../img/4star/祭礼残章.jpg",
    name: "祭礼残章"
};

const star4_10 = {
    src_p: "../img/4star/祭礼大剑.jpg",
    name: "祭礼大剑"
};

const star4_11 = {
    src_p: "../img/4star/祭礼弓.jpg",
    name: "祭礼弓"
};
const star4_12 = {
    src_p: "../img/4star/凯亚.jpg",
    name: "凯亚"
};

const star4_13 = {
    src_p: "../img/4star/雷泽.jpg",
    name: "雷泽"
};
const star4_14 = {
    src_p: "../img/4star/丽莎.jpg",
    name: "丽莎"
};
const star4_15 = {
    src_p: "../img/4star/流浪乐章.jpg",
    name: "流浪乐章"
};
const star4_16 = {
    src_p: "../img/4star/罗莎莉亚.jpg",
    name: "罗莎莉亚"
};

const star4_17 = {
    src_p: "../img/4star/凝光.jpg",
    name: "凝光"
};

const star4_18 = {
    src_p: "../img/4star/诺艾尔.jpg",
    name: "诺艾尔"
};
const star4_19 = {
    src_p: "../img/4star/砂糖.jpg",
    name: "砂糖"
};
const star4_20 = {
    src_p: "../img/4star/西风大剑.jpg",
    name: "西风大剑"
};

const star4_21 = {
    src_p: "../img/4star/西风剑.jpg",
    name: "西风剑"
};
const star4_22 = {
    src_p: "../img/4star/西风猎弓.jpg",
    name: "西风猎弓"
};
const star4_23 = {
    src_p: "../img/4star/匣里龙吟.jpg",
    name: "匣里龙吟"
};

const star4_24 = {
    src_p: "../img/4star/匣里灭辰.jpg",
    name: "匣里灭辰"
};
const star4_25 = {
    src_p: "../img/4star/香菱.jpg",
    name: "香菱"
};

const star4_26 = {
    src_p: "../img/4star/辛焱.jpg",
    name: "辛焱"
};
const star4_27 = {
    src_p: "../img/4star/行秋.jpg",
    name: "行秋"
};
const star4_28 = {
    src_p: "../img/4star/烟绯.jpg",
    name: "烟绯"
};
const star4_29 = {
    src_p: "../img/4star/雨裁.jpg",
    name: "雨裁"
};
const star4_30 = {
    src_p: "../img/4star/昭心.jpg",
    name: "昭心"
};
const star4_31 = {
    src_p: "../img/4star/重云.jpg",
    name: "重云"
};

//三星
const star3_1 = {
    src_p: "../img/3star/翠玉法球.jpg",
    name: "翠玉法球"
};
const star3_2 = {
    src_p: "../img/3star/弹弓.jpg",
    name: "弹弓"
};
const star3_3 = {
    src_p: "../img/3star/飞天御剑.jpg",
    name: "飞天御剑"
};
const star3_4 = {
    src_p: "../img/3star/黑缨枪.jpg",
    name: "黑缨枪"
};
const star3_5 = {
    src_p: "../img/3star/冷刃.jpg",
    name: "冷刃"
};
const star3_6 = {
    src_p: "../img/3star/黎明神剑.jpg",
    name: "黎明神剑"
};
const star3_7 = {
    src_p: "../img/3star/魔导绪论.jpg",
    name: "魔导绪论"
};
const star3_8 = {
    src_p: "../img/3star/沐浴龙血的剑.jpg",
    name: "沐浴龙血的剑"
};
const star3_9 = {
    src_p: "../img/3star/神射手之誓.jpg",
    name: "神射手之誓"
};

const star3_10 = {
    src_p: "../img/3star/讨龙英杰谭.jpg",
    name: "讨龙英杰谭"
};
const star3_11 = {
    src_p: "../img/3star/铁影阔剑.jpg",
    name: "铁影阔剑"
};
const star3_12 = {
    src_p: "../img/3star/翠玉法球.jpg",
    name: "翠玉法球"
};
const star3_13 = {
    src_p: "../img/3star/鸦羽弓.jpg",
    name: "鸦羽弓"
};

const star3_14 = {
    src_p: "../img/3star/以理服人.jpg",
    name: "以理服人"
};
//数组
const array_5star_character = [
    star5_character1, star5_character2, star5_character3, star5_character4, star5_character5, star5_character6, star5_character7,
    star5_character8, star5_character9, star5_character10, star5_character11, star5_character12
];
const array_5star_arms = [
    star5_arms1, star5_arms2, star5_arms3, star5_arms4, star5_arms5, star5_arms6, star5_arms7, star5_arms8, star5_arms9,
    star5_arms10, star5_arms11, star5_arms12, star5_arms13, star5_arms14, star5_arms15, star5_arms16, star5_arms17, star5_arms18
];
const array_4star = [
    star4_1, star4_2, star4_3, star4_4, star4_5, star4_6, star4_7, star4_8, star4_9, star4_10,
    star4_11, star4_12, star4_13, star4_14, star4_15, star4_16, star4_17, star4_18, star4_19, star4_20,
    star4_21, star4_22, star4_23, star4_24, star4_25, star4_26, star4_27, star4_28, star4_29, star4_30,
    star4_31
];
const array_3star = [
        star3_1, star3_2, star3_3, star3_4, star3_5, star3_6, star3_7, star3_8, star3_9, star3_10, star3_11, star3_12, star3_13, star3_14
    ]
    //3.创建路由则
    //request是对请求报文的封装
    //response是对响应报文的封装


//单抽
app.get("/server", (request, response) => {
    //!设置响应头    设置允许跨域
    response.setHeader("Access-Control-Allow-Origin", "*");
    response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE, PUT");
    response.setHeader("Access-Control-Max-Age", "3600");
    response.setHeader("Access-Control-Allow-Headers", "Content-Type,Access-Token,Authorization,ybg");
    //!设置响应体
    let array_data = [
        array_5star_character, array_5star_arms, array_4star, array_3star
    ];
    let data = {};
    if (Math.random() <= 0.006) {
        let rom1 = Math.ceil(Math.random() * 12 - 1);
        data = array_data[0][rom1];
    } else if (Math.random() <= 0.056 && Math.random() > 0.006) {
        let rom2 = Math.ceil(Math.random() * 31 - 1);
        data = array_data[2][rom2];
    } else {
        let roms = Math.ceil(Math.random() * 14 - 1);
        data = array_data[3][roms];
    }
    let str = JSON.stringify(data);
    response.send(data);
})


//十连
app.get("/shilian", (request, response) => {
        //!设置响应头    设置允许跨域
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE, PUT");
        response.setHeader("Access-Control-Max-Age", "3600");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type,Access-Token,Authorization,ybg");
        //!设置响应体
        let array_data = [
            array_5star_character, array_5star_arms, array_4star, array_3star
        ];
        let data = [];
        let p = Math.ceil(Math.random() * 10 - 1)
        let s = p;
        for (let i = 0; i < 10; i++) {
            if (i === s) {
                let rom2 = Math.ceil(Math.random() * 31 - 1);
                data[i] = array_data[2][rom2];
            } else if (Math.random() <= 0.006) {
                let rom1 = Math.ceil(Math.random() * 12 - 1);
                data[i] = array_data[0][rom1];
            } else if (Math.random() <= 0.056 && Math.random() > 0.006) {
                let rom2 = Math.ceil(Math.random() * 31 - 1);
                data[i] = array_data[2][rom2];
            } else {
                let roms = Math.ceil(Math.random() * 14 - 1);
                data[i] = array_data[3][roms];
            }
        }
        response.send(data);
    })
    //4.监听端口
app.listen(8000, () => {
    console.log("服务已经启动，8000端口监听中！");
})